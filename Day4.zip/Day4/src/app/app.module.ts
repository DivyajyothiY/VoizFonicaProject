import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AboutUsComponent } from './about-us/about-us.component';

import { RechargeComponent } from './recharge/recharge.component';
import { ViewplansComponent } from './viewplans/viewplans.component';
import { NewprepaidsimComponent } from './newprepaidsim/newprepaidsim.component';
import { PrepaidtopostpaidComponent } from './prepaidtopostpaid/prepaidtopostpaid.component';
import { ContactusComponent } from './contactus/contactus.component';


@NgModule({
    declarations:[     
    AppComponent,
    UserloginComponent,
 AboutUsComponent,
 RechargeComponent,
 ViewplansComponent,
 NewprepaidsimComponent,
 PrepaidtopostpaidComponent,
 ContactusComponent,

    
  
  ],
    imports:[
BrowserModule,
AppRoutingModule,
    ],
    providers:[],
    bootstrap:[AppComponent]
    
})
export class AppModule { }


    



/*import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ViewPlansComponent } from './view-plans/view-plans.component';
import { RechargeComponent } from './recharge/recharge.component';
import { NewPrepaidSIMComponent } from './new-prepaid-sim/new-prepaid-sim.component';

@NgModule({
    declarations:[     
    AppComponent,
    UserloginComponent,
 AboutUsComponent,
 ViewPlansComponent,
 RechargeComponent,
 NewPrepaidSIMComponent,
    
  
  ],
    imports:[
BrowserModule,
AppRoutingModule,
    ],
    providers:[],
    bootstrap:[AppComponent]
    
})
export class AppModule { }*/


