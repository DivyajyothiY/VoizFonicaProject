import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewplans',
  templateUrl: './viewplans.component.html',
  styleUrls: ['./viewplans.component.css']
})
export class ViewplansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
