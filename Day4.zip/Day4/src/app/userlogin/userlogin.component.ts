import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

/*import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
}*/
 /* selectedName = "Recharge";
  data = [
     {id:0, value:"Recharge" , route:"recharge"},
    {id:1, value:"New Prepaid SIM" , route:"New Prepaid SIM"},
    {id:2, value:"View Plans",  route:"View Plans"},
    {id:3, value:"Switch Prepaid to PostPaid" , route:"Switch Prepaid to Postpaid"}
  ]

  constructor(private router:Router) {
  
   }

  ngOnInit(): void {

  }
  recharge(){
    this.router.navigate(['/recharge'])
  }
  selectedItem(name:any){
    
/*console.log(name);*/
/*document.write(name);


  }
}*/

