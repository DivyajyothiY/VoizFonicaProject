import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuynewconnectionComponent } from './buynewconnection.component';

describe('BuynewconnectionComponent', () => {
  let component: BuynewconnectionComponent;
  let fixture: ComponentFixture<BuynewconnectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuynewconnectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuynewconnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
