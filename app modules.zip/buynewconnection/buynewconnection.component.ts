import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buynewconnection',
  templateUrl: './buynewconnection.component.html',
  styleUrls: ['./buynewconnection.component.css']
})
export class BuynewconnectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
