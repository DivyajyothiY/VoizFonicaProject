import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newprepaidsim',
  templateUrl: './newprepaidsim.component.html',
  styleUrls: ['./newprepaidsim.component.css']
})
export class NewprepaidsimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
