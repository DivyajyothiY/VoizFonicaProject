import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewprepaidsimComponent } from './newprepaidsim.component';

describe('NewprepaidsimComponent', () => {
  let component: NewprepaidsimComponent;
  let fixture: ComponentFixture<NewprepaidsimComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewprepaidsimComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewprepaidsimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
