import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.css']
})
export class AdminpanelComponent implements OnInit {

  constructor(
    private router:Router
  ) { }

  ngOnInit(): void {
  }
  admin_details(){
    this.router.navigate(['/admindetails'])
  }
  customer_details(){
    this.router.navigate(['/customerdetails'])
  }
  customer_queries(){
    this.router.navigate(['/customerqueries'])
  }
  logout(){
    this.router.navigate(['/home'])
  }
  add_new_customer(){
    this.router.navigate(['/addnewcustomer'])
  }


}
