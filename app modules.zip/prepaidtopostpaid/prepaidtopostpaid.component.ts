import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaidtopostpaid',
  templateUrl: './prepaidtopostpaid.component.html',
  styleUrls: ['./prepaidtopostpaid.component.css']
})
export class PrepaidtopostpaidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
