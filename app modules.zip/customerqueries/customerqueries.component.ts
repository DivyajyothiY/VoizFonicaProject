import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerqueries',
  templateUrl: './customerqueries.component.html',
  styleUrls: ['./customerqueries.component.css']
})
export class CustomerqueriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
