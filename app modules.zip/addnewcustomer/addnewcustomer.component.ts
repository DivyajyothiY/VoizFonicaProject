import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnewcustomer',
  templateUrl: './addnewcustomer.component.html',
  styleUrls: ['./addnewcustomer.component.css']
})
export class AddnewcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
