import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-prepaid-sim',
  templateUrl: './new-prepaid-sim.component.html',
  styleUrls: ['./new-prepaid-sim.component.css']
})
export class NewPrepaidSIMComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
