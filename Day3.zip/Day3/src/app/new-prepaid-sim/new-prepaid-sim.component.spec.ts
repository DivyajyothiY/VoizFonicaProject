import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPrepaidSIMComponent } from './new-prepaid-sim.component';

describe('NewPrepaidSIMComponent', () => {
  let component: NewPrepaidSIMComponent;
  let fixture: ComponentFixture<NewPrepaidSIMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewPrepaidSIMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPrepaidSIMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
