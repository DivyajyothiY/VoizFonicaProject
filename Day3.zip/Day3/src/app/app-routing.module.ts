import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AppComponent } from './app.component';
import { RechargeComponent } from './recharge/recharge.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { ViewPlansComponent } from './view-plans/view-plans.component';
const routes: Routes = [
    {path:'userlogin',component:UserloginComponent},
    {path:'about-us', component:AboutUsComponent},
    /*{path:'new-prepaid-sim',component:NewprepaidsimComponent},*/
{path:'view-plans',component:ViewPlansComponent},
    {path:'recharge',component:RechargeComponent},
    {path: '', redirectTo: '/userlogin', pathMatch: 'full'},
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRoutingModule{}