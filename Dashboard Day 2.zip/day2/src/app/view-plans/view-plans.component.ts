import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-plans',
  templateUrl: './view-plans.component.html',
  styleUrls: ['./view-plans.component.css']
})
export class ViewPlansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
