import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ViewPlansComponent } from './view-plans/view-plans.component';
import { RechargeComponent } from './recharge/recharge.component';

@NgModule({
    declarations:[     
    AppComponent,
    UserloginComponent,
 AboutUsComponent,
 ViewPlansComponent,
 RechargeComponent
    
  
  ],
    imports:[
BrowserModule,
AppRoutingModule,
    ],
    providers:[],
    bootstrap:[AppComponent]
    
})
export class AppModule { }


