import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';

const routes: Routes = [
  {path:'userregistration',component:UserregistrationComponent},
  {path:'register',component:RegisterComponent},
  {path: '', redirectTo: '/register', pathMatch: 'full'},
  {path:'userlogin',component:UserloginComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
