import { Component, OnInit } from '@angular/core';
 
@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
